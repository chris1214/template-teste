<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
/* body */
body {
  background-color: #E9ECEE;
  font-family: 'Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif !important;
  font-size: 12px !important;
}
/* body */

</style>
