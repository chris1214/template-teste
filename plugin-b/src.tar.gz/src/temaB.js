/**
 * Created by christopher on 12/09/17.
 */
import Vue from 'vue'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-default/index.css'

import locale from 'element-ui/lib/locale/lang/pt-br'


Vue.use(ElementUI, { locale });
