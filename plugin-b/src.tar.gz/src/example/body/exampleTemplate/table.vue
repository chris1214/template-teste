<script>
    export default{
        data(){
            return{
              tableData: [{
                date: '2016-05-03',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-02',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-04',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }, {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles'
              }]
            }
        },
    }
</script>

<template>
    <div>
      <div class="row">
        <div class="col-md-12">

          <el-table
            stripe
            class="tabela"
            :data="tableData"
            border>
            <el-table-column
              prop="date"
              label="Date"
              width="180">
            </el-table-column>
            <el-table-column
              prop="name"
              label="Name"
              width="180">
            </el-table-column>
            <el-table-column
              prop="address"
              label="Address">
            </el-table-column>
          </el-table>

        </div>
      </div>
    </div>
</template>

<style scoped>
/* table */

.el-table th {
  background-color: #ffffff !important;
}
.el-table__header-wrapper thead div {
  background-color: #ffffff !important;
}
.el-table th {
  font-size: 13px !important;
  font-weight: 600;
  font-family: 'Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif !important;

}
.el-table td {
  font-size: 12px;
  font-family: 'Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif !important;

}
/* table */
</style>
