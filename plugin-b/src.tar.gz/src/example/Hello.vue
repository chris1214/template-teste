<template>
  <div>
    <a href="#/login01">login01</a>
    <br>
    <br>
    <a href="#/login02">login02</a>
    <br>
    <br>
    <a href="#/login03">login03</a>
    <br>
    <br>
    <a href="#/login04">login04</a>
    <br>
    <br>
    <a href="#/templateDefalt">templateDefalt</a>
    <br>
    <br>
    <a href="#/aside">aside</a>
    <br>
    <br>
    <a href="#/login01Scroll">login01Scroll</a>
    <br>
    <br>
    <a href="#/login02Scroll">login02Scroll</a>
    <br>
    <br>
    <a href="#/login03Scroll">login03Scroll</a>

  </div>
</template>

<script>
export default {
    data() {
      return {
      }
    },
  components:{
  }
}
</script>
